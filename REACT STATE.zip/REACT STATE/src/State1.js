import React,{useState} from 'react';

function State1()
{
    const [count, setCount] = useState(0);
    return(
       <center>
         <h1>{count}</h1>
        <button onClick={()=>setCount(count+1)}>Increment</button>
        <button onClick={()=>setCount(count-1)}>Decrement</button>
       </center>
    );
}

export default State1;