import React from 'react';
import ReactDOM from 'react-dom/client';
import State1 from './State1';



function App() {
  
  const root = ReactDOM.createRoot(document.getElementById('root'));
  root.render(
    <React.StrictMode>
      <State1 />
    </React.StrictMode>
  );
  //  const [count, setCount] = useState(1);
//   return (
//     <center>
//       <h1>{count}</h1>
//       <button onClick={()=>setCount(count +1) }>Increment</button>
//       <button onClick={()=>setCount(count -1) }>Decrement</button>
//     </center>
//   );
}

export default App;
